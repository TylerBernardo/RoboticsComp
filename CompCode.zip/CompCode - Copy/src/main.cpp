/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Clawbot Competition Template                              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// LeftMotor            motor         1               
// RightMotor           motor         10              
// LeftMotor2           motor         2               
// RightMotor2          motor         9               
// PickupMotorLeft      motor         5               
// PickupMotorRight     motor         4               
// armMotorLeft         motor         6               
// armMotorRight        motor         7               
// ---- END VEXCODE CONFIGURED DEVICES ----
        

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  armMotorLeft.resetRotation();
  armMotorRight.resetRotation();
  
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

double value = 0;
int x = 0;
int i = 0;
double spi = 0.0275;
int y = 0;
int c = 0;
int myTimer = 0;
int test = 0;
int test2 = 0;
double armMotorRotation = armMotorLeft.rotation(deg);
//assumed speed is 12 inchs in .3 seconds

void intakeReset() {
  int resetPostion = 0; //90 until otherproven by testing code on robot
  PickupMotorLeft.rotateTo(resetPostion , rotationUnits::deg , false);
  PickupMotorRight.rotateTo(resetPostion , rotationUnits::deg , false);
}

void armMove(int direction) {
  // 1 = up, -1 = down
  double mPower = 1;
  int currentRotation = armMotorLeft.rotation(rotationUnits::deg);
  // //10% power decrease for each 8.5 degrees moved
  double rate = currentRotation / 13;
  int Power = mPower - rate;
  armMotorLeft.spin(directionType::fwd, Power * direction, velocityUnits::pct);
  armMotorRight.spin(directionType::fwd, Power * direction, velocityUnits::pct);
}  

void armStop() {
  vex::task::sleep( 10 );
  armMotorLeft.stop();
  armMotorRight.stop();
}



void turn ( int distance, int direction) {
  int move;
  move = distance*direction;
  //LeftMotor.spin(directionType::fwd, distance, velocityUnits::deg); 
  //RightMotor.spin(directionType::fwd, distance , velocityUnits::pct);
  LeftMotor.rotateFor(move, rotationUnits::deg);
  LeftMotor2.rotateFor(move, rotationUnits::deg);
  RightMotor.rotateFor(-move, rotationUnits::deg);
  RightMotor2.rotateFor(-move, rotationUnits::deg);
}

void moveLeft ( int mpower , int onOff) {
  if( onOff == 1){
    // implement stoping
    LeftMotor.setVelocity(0 , velocityUnits::pct);
    LeftMotor2.setVelocity(0 , velocityUnits::pct);
    LeftMotor.spin(forward);
    LeftMotor2.spin(forward);
    return;
  }else{
    // power is on percent
    // onOff controls whether to start or stop, 0 = on, 1 = off
    LeftMotor.setVelocity(mpower , velocityUnits::pct);
    LeftMotor2.setVelocity(mpower , velocityUnits::pct);
    LeftMotor.spin(forward);
    LeftMotor2.spin(forward);
  }
}

void moveRight ( int mpower , int onOff) {
  if( onOff == 1){
   // implement stoping
    RightMotor.setVelocity(0 , velocityUnits::pct);
    RightMotor2.setVelocity(0 , velocityUnits::pct);
    RightMotor.spin(forward);
    RightMotor2.spin(forward);
    return;
  }else{
    // power is on percent
    // onOff controls whether to start or stop, 0 = on, 1 = off
     RightMotor.setVelocity(mpower , velocityUnits::pct);
    RightMotor2.setVelocity(mpower , velocityUnits::pct);
    RightMotor.spin(forward);
    RightMotor2.spin(forward);
  }
}

void moveLeftAuto (double time , int power) {
  //distance is in inchs
  for(int t = 0; t <= time ,t = t + .0001; ) {
  LeftMotor.spin(directionType::fwd, power , velocityUnits::pct);
  LeftMotor2.spin(directionType::fwd, power , velocityUnits::pct);
  wait(.0001 , seconds);
  }
}

void moveRightAuto (double time , int power) {
  //distance is in inchs
  for(int t = 0; t <= time ,t = t + .0001; ) {
  RightMotor.spin(directionType::fwd, power , velocityUnits::pct);
  RightMotor2.spin(directionType::fwd, power , velocityUnits::pct);
  wait(.0001 , seconds);
  }
}

void speedToggle(){
  Brain.Screen.clearLine();
  Brain.Screen.print(test2);
  test2 = test2 + 1;
  if(x == 0){
  x = 1;
  }else{
  x = 0;
  }
}

void pickupToggleOn() {
  Brain.Screen.clearLine();
  Brain.Screen.print(test);
  test = test + 1;
  y = 1;
}

void pickupToggleOff() {
  Brain.Screen.clearLine();
  Brain.Screen.print(test);
  test = test + 1;
  y = 0;
}

void strafeLeft(){
  LeftMotor.spin(directionType::fwd, -127 , velocityUnits::pct);
  LeftMotor2.spin(directionType::fwd, 127 , velocityUnits::pct);
  RightMotor.spin(directionType::fwd, 127 , velocityUnits::pct);
  RightMotor2.spin(directionType::fwd, -127 , velocityUnits::pct);
}

void strafeRight() {
  LeftMotor.spin(directionType::fwd, 127 , velocityUnits::pct);
  LeftMotor2.spin(directionType::fwd, -127 , velocityUnits::pct);
  RightMotor.spin(directionType::fwd, -127 , velocityUnits::pct);
  RightMotor2.spin(directionType::fwd, 127 , velocityUnits::pct);
}

void automatic() {
  //autocode in here
  // make sure to use moveLeftAuto() and moveRightAuto()
}

void pickupCode(int direction) {
  PickupMotorLeft.spin(directionType::fwd, 127 * direction , velocityUnits::pct);
  PickupMotorRight.spin(directionType::fwd, 127 * direction, velocityUnits::pct);
}

void pickupStop() {
  vex::task::sleep( 10 );
  PickupMotorLeft.stop();
  PickupMotorRight.stop();
}

void autoTest() {
  Brain.Screen.clearLine();
  Brain.Screen.print("autonomous is running");
  while(Brain.timer(sec) <= 5  &&  LeftMotor.position(degrees) <=90 ){
  LeftMotor.spin(reverse);
  LeftMotor2.spin(reverse);
  RightMotor.spin(reverse);
  RightMotor2.spin(reverse);
  }

  Brain.Screen.clearLine();
  Brain.Screen.print("halfway there!");

  LeftMotor.spin(forward);
  LeftMotor2.spin(forward);
  RightMotor.spin(forward);
  RightMotor2.spin(forward);
  wait(2, seconds);

  LeftMotor.stop();
  LeftMotor2.stop();
  RightMotor.stop();
  RightMotor2.stop();
  Brain.Screen.clearLine();
  Brain.Screen.print("autonomous has ended");
}

void allRotateFor(double distance){
  LeftMotor.spinFor(directionType::fwd, distance , degrees);
  LeftMotor2.spinFor(directionType::fwd, distance , degrees);
  RightMotor.spinFor(directionType::fwd, distance , degrees);
  RightMotor2.spinFor(directionType::fwd, distance , degrees);
}

void driveNormal() {
  if(Controller1.ButtonL1.pressing() == 1){
    pickupCode(1);
  }
  if(x == 0){
    Controller1.ButtonX.pressed(intakeReset); 
    Controller1.ButtonUp.pressed(autoTest);
    // normal mode
  int leftPower  = Controller1.Axis3.value();
  int rightPower = Controller1.Axis2.value();
  moveLeft(leftPower , 0);
  moveRight(rightPower, 0);
    }else{
    Controller1.ButtonX.pressed(intakeReset);

    
    //slow mode
  int leftPower  = .25*(Controller1.Axis3.value());
  int rightPower = .25*(Controller1.Axis2.value());
  moveLeft(leftPower , 0);
  moveRight(rightPower, 0);
  }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
  Brain.Screen.clearLine();
  Brain.Screen.print("autonomous is running");
LeftMotor.setTimeout(5, seconds);
LeftMotor2.setTimeout(5, seconds);
RightMotor.setTimeout(5, seconds);
RightMotor2.setTimeout(5, seconds);

LeftMotor.spinFor( reverse, 90, degrees, false );
LeftMotor2.spinFor( reverse, 90, degrees, false );
RightMotor.spinFor( reverse, 90, degrees, false );
RightMotor2.spinFor( reverse, 90, degrees, true );
  LeftMotor.resetRotation();
  Brain.Timer.reset();
  Brain.Screen.clearLine();
  Brain.Screen.print("halfway there!");

  LeftMotor.setTimeout(5, seconds);
LeftMotor2.setTimeout(5, seconds);
RightMotor.setTimeout(5, seconds);
RightMotor2.setTimeout(5, seconds);

LeftMotor.spinFor( forward, 90, degrees, false );
LeftMotor2.spinFor( forward, 90, degrees, false );
RightMotor.spinFor( forward, 90, degrees, false );
RightMotor2.spinFor( forward, 90, degrees, true );
  LeftMotor.resetRotation();
  Brain.Screen.clearLine();
  Brain.Timer.reset();

  LeftMotor.stop();
  LeftMotor2.stop();
  RightMotor.stop();
  RightMotor2.stop();
  Brain.Screen.clearLine();
  Brain.Screen.print("autonomous has ended");
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  Controller1.ButtonX.pressed(intakeReset); 
  Controller1.ButtonL1.released(pickupStop);
  Controller1.ButtonR1.released(armStop);
  Controller1.ButtonR2.released(armStop);
  if(armMotorLeft.rotation(rotationUnits::deg) > 360){
    armMotorLeft.setRotation(1 , rotationUnits::deg);
  }
  while(1 == 1){
    if(Controller1.ButtonLeft.pressing() == 1 && Controller1.ButtonA.pressing() == 1){
      driveNormal();
      //if both l1 and r1 are pressed
    }else{
      if(Controller1.ButtonLeft.pressing() == 1) {
      //strafe left
      strafeLeft();
      }else{
       if(Controller1.ButtonA.pressing() == 1) {
        //strafe right if not strafing left
        strafeRight();
        }else{
          if(Controller1.ButtonR1.pressing() == 1 && Controller1.ButtonR2.pressing() == 1){
            driveNormal();
            }else{
              //cant raise or lower arm while strafing, will happen from now
              if(Controller1.ButtonR1.pressing() == 1){
                armMove(1);
               }else{
                if(Controller1.ButtonR2.pressing() == 1) {
                  //insert arm lower code
                  armMove(-1);
                }else{
                  driveNormal();
            }
          }
      }
    }
      
  }
  }
  }

  }


//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();
  autonomous();
  usercontrol();
  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
